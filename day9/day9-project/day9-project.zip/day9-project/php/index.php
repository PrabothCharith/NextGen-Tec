<?php

$name = "John";

// echo "Hello World! This is a PHP file.";

echo "My name is $name.";

