<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./src/input.css" />
    <link rel="stylesheet" href="./src/output.css" />
</head>

<body>

    <h1 class="text-4xl text-center font-bold text-red-500">This is a PHP file with HTML and Tailwind</h1>

</body>

</html>